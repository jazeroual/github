<?
mail('tzanzouri@hotmail.com','Commande RestoNumerik','Détail commande...');
?>
